import React from 'react'

export default function page() {
  return (
    <div>Medical visa</div>
  )
}
