export interface Blogs {
    id: number;
    title: string;
    content: string;
    image: string;
    category:string[];
}
export interface Videos {
    id: number;
    title: string;
    content: string;
    image: string;
}